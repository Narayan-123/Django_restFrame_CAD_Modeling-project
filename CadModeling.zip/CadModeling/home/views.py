from django.shortcuts import render
from .models import CAD_files

# Create your views here.
def index(request):
    files_list=CAD_files.objects.all() #books_list->files_list
    return render(request,'index.html',{'cads':files_list}) #books->cads

#login and pass for admin - admin, admin