from django import forms

from .models import CAD_files

class CADForm(forms.ModelForm): # BookForm -> CADForm
    class Meta:
        model=CAD_files
        fields="__all__"