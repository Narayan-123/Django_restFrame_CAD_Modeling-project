from django.db import models

# Create your models here.
class CAD_files(models.Model): #Book -> CAD_files
    name=models.CharField(max_length=100)
    picture=models.ImageField()
    Designer=models.CharField(max_length=100)
    description=models.TextField()

    def __str__(self):
       result=self.name+" by "+self.Designer
       return result

