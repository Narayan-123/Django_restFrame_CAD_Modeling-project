from django.contrib import admin
from .models import CAD_files

# Register your models here.
admin.site.register(CAD_files)

